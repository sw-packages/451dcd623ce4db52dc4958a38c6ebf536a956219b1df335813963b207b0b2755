**The APIs in this directory are not stable!**

This directory contains header files that need to be installed but are not part
of the public API. Users should not use these headers directly.
